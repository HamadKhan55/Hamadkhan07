# Install
```
$ pkg update && pkg upgrade
$ pkg install git
$ pkg install python2
$ git clone https://github.com/V4N654T/fb-hacker
$ cd fb-hacker
$ python2 fb.py
```
# thanks to
#### All members D4RKN355 T34M
#### Fachri Yuzzy
#### Allah SWT
